package com.sehirgezintisi.app.HelperClasses.Interfaces;

public interface AutoCompleteAdapterClickListener {
    void onSearchedItemClick(int position);
}

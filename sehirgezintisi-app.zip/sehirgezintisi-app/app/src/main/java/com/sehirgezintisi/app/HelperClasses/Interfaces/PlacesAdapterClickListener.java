package com.sehirgezintisi.app.HelperClasses.Interfaces;

public interface PlacesAdapterClickListener {
    void onCardClick(int position);
}
